class Point {
    private double X;
    private double Y;

    public Point(double a, double b) {
        X = a;
        Y = b;
    }

    public Point() {
        X = Y = 0;
    }

    public double getX() {
        return X;
    }

    public double getY() {
        return Y;
    }
}

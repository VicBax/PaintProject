import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Window extends JFrame implements ActionListener {
    private Drawing myDrawing;

    public Window(String Title) {
        super(Title);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocation(500,300);
        setSize(800,500);
        Container container = getContentPane();
        JMenuBar m_barre = new JMenuBar();
        JMenu m_File = new JMenu("File");
        JMenu m_A_About = new JMenu("A Propos");
        JMenuItem sm_Open = new JMenuItem("Open");
        JMenuItem sm_New = new JMenuItem("New");
        JMenuItem sm_Save = new JMenuItem("Save");
        JMenuItem sm_Exit = new JMenuItem("Exit");
        JMenuItem sm_Author = new JMenuItem("Author");

        m_File.add(sm_Open);
        m_File.addSeparator();
        m_File.add(sm_New);
        m_File.addSeparator();
        m_File.add(sm_Save);
        m_File.addSeparator();
        m_File.add(sm_Exit);

        m_A_About.add(sm_Exit);

        m_barre.add(m_File);
        m_barre.add(m_A_About);

        setJMenuBar(m_barre);

        sm_Open.setAccelerator((KeyStroke.getKeyStroke('N',Toolkit.getDefaultToolkit().getMenuShortcutKeyMask(),false)));
        sm_New.setAccelerator((KeyStroke.getKeyStroke('L',Toolkit.getDefaultToolkit().getMenuShortcutKeyMask(),false)));
        sm_Save.setAccelerator((KeyStroke.getKeyStroke('M',Toolkit.getDefaultToolkit().getMenuShortcutKeyMask(),false)));
        sm_Exit.setAccelerator((KeyStroke.getKeyStroke('P',Toolkit.getDefaultToolkit().getMenuShortcutKeyMask(),false)));

        myDrawing = new Drawing();
        container.add(myDrawing,"Center");
        JPanel main_grid = new JPanel();
        JPanel colors_grids = new JPanel();
        JPanel figures_grids = new JPanel();
        main_grid.setLayout(new GridLayout(1,2));
        colors_grids.setLayout(new GridLayout(2,4));
        figures_grids.setLayout(new GridLayout(2,2));
        JButton b_noir = new JButton("Black");
        b_noir.setBackground(Color.black);
        b_noir.setForeground(Color.white);
        JButton b_rouge = new JButton("Red");
        b_rouge.setBackground(Color.red);
        JButton b_vert = new JButton("Green");
        b_vert.setBackground(Color.green);
        JButton b_bleu = new JButton("Blue");
        b_bleu.setBackground(Color.blue);
        JButton b_jaune = new JButton("Yellow");
        b_jaune.setBackground(Color.yellow);
        JButton b_rose = new JButton("Pink");
        b_rose.setBackground(Color.pink);
        JButton b_violet = new JButton("Purple");
        b_violet.setBackground(Color.magenta);
        JButton b_orange = new JButton("Orange");
        b_orange.setBackground(Color.orange);
        colors_grids.add(b_noir);
        colors_grids.add(b_rouge);
        colors_grids.add(b_vert);
        colors_grids.add(b_bleu);
        colors_grids.add(b_jaune);
        colors_grids.add(b_rose);
        colors_grids.add(b_violet);
        colors_grids.add(b_orange);
        figures_grids.add(new JButton("Ellipse"));
        figures_grids.add(new JButton("Circle"));
        figures_grids.add(new JButton("Rectangle"));
        figures_grids.add(new JButton("Square"));
        main_grid.add(colors_grids);
        main_grid.add(figures_grids);
        container.add(main_grid,"South");
        sm_Open.addActionListener(this);
        sm_Save.addActionListener(this);
        sm_New.addActionListener(this);
        sm_Exit.addActionListener(this);
        sm_Author.addActionListener(this);
        b_noir.addActionListener(this);
        b_rouge.addActionListener(this);
        b_vert.addActionListener(this);
        b_bleu.addActionListener(this);
        b_jaune.addActionListener(this);
        b_rose.addActionListener(this);
        b_violet.addActionListener(this);
        b_orange.addActionListener(this);
        setVisible(true);
    }


    public void actionPerformed(ActionEvent e){
        String cmd = e.getActionCommand();
        if(cmd.equals("Nouveau")) {}
        else if(cmd.equals("Quitter")) {System.exit(0);}
        else if(cmd.equals("Rectangle") || cmd.equals("Square") || cmd.equals("Ellipse") || cmd.equals("Circle")){myDrawing.setShape(cmd);}
        else if(cmd.equals("Black")){myDrawing.setColor(Color.black);}
        else if(cmd.equals("Red")){myDrawing.setColor(Color.red);}
        else if(cmd.equals("Green")){myDrawing.setColor(Color.green);}
        else if(cmd.equals("Blue")){myDrawing.setColor(Color.blue);}
        else if(cmd.equals("Yellow")){myDrawing.setColor(Color.yellow);}
        else if(cmd.equals("Pink")){myDrawing.setColor(Color.pink);}
        else if(cmd.equals("Purple")){myDrawing.setColor(Color.magenta);}
        else if(cmd.equals("Orange")){myDrawing.setColor(Color.orange);}
        else {System.err.println("You clicked on " + cmd);}
    }
}

class Test {

    public static void main(String args[]) {
        Window Win = new Window("Welcome on the first window");
        System.out.println("On voit");
    }
}

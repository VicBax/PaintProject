class Rectangle extends Shape{
    protected double length;
    protected double width;

    public Rectangle(double width, double length) {
        super(new Point(width/2,length/2));
        this.length = length;
        this.width = width;
    }

    public double getLength() {
        return length;
    }

    public double getWidth() {
        return width;
    }

    public Point getOrgine() {
        return origine;
    }

    public double getPerimeter() {
        return 2*length + 2*width;
    }

    public double getSurface() {
        return length*width;
    }

    public void setLength(double length) {
        this.length = length;
    }

    public void setWidth(double width) {
        this.width = width;
    }

    public String toString() {
        String s="";
        for (int len=0;len<length;len++) {
            for (int wid=0;wid<width;wid++) {
                if ((len==0 && wid==0) || (len==length-1 && wid==0)) {
                    s+="+";
                }
                else if ((len==0 && wid==width-1) || (len==length-1)) {
                    s+="+\n";
                }
                else if ((len==0) || (len==length-1)) {
                    s+="--";
                }
                else if (wid==0) {
                    s+="|";
                }
                else if (wid==width-1) {
                    s+="|\n";
                }
                else {
                    s+="";
                }
            }
        }
        return s;
    }
}

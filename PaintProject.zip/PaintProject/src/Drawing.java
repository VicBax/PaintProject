import javax.swing.*;
import java.awt.*;
import java.util.*;

class Drawing extends JPanel {
    private ArrayList<Shape> list;
    private Color c;
    private String nameShape;

    public Drawing() {
        super();
        c = Color.black;
        nameShape = "Rectangle";
        list = new ArrayList<Shape>();
    }

    public void paintComponent (Graphics g) {
        super.paintComponent(g);
        int length = getSize().width;
        int width = getSize().height;
        setBackground(Color.white);
        g.setColor(Color.red);
        g.fillRect(length/4,width/4,length/2,width/2);
    }

    public void setColor(Color color) {
        c = color;
    }

    public void setShape(String name) {
        nameShape = name;
    }

    public ArrayList<Shape> getList() {
        return list;
    }
}

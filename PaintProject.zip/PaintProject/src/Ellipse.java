import java.lang.Math;

class Ellipse extends Shape {
    protected double bigaxe;
    protected double smallaxe;

    public Ellipse(double bigaxe, double smallaxe) {
        super(new Point(bigaxe/2,smallaxe/2));
        this.bigaxe = bigaxe;
        this.smallaxe = smallaxe;
    }

    public double getSurface(){
        return Math.PI*bigaxe*smallaxe/4;
    }

    public double getPerimeter() {
        return 2*Math.PI*Math.sqrt((bigaxe*bigaxe + smallaxe*smallaxe)/2);
    }

    public double getBigAxe() {
        return bigaxe;
    }

    public double getSmallAxe() {
        return smallaxe;
    }

    public void setBigAxe(double bigaxe) {
        this.bigaxe = bigaxe;
    }

    public void setSmallAxe(double smallaxe) {
        this.smallaxe = smallaxe;
    }
}

public abstract class Shape {

    protected Point origine;

    public Shape(Point pt) {
        origine = pt;
    }

    public String toString() {
        return "("+origine.getX()+","+origine.getY()+")";
    }

    public abstract double getPerimeter();

    public abstract double getSurface();
}

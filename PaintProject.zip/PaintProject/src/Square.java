import java.awt.*;

class Square extends Rectangle {

    public Square(double width){
        super(width, width);
    }

    public String toString(){
        String s="";
        for (int width1=0; width1<width; width1++) {
            for (int width2=0; width2<width; width2++) {
                if ((width1==0 && width2==0) || (width1==width-1 && width2==0)) {
                    s+="+";
                }
                else if ((width1==0 && width2==width-1) || (width1==width-1 && width2==width-1)){
                    s+="+\n";
                }
                else if ((width1==0) || (width1==width-1)) {
                    s+="--";
                }
                else if (width2==0) {
                    s+="|";
                }
                else if (width2==width-1) {
                    s+="|\n";
                }
                else {
                    s+="";
                }
            }
        }
        return s;
    }
}

class Circle extends Ellipse {
    public Circle(double radius) {
        super(radius, radius);
        bigaxe = radius;
        smallaxe = radius;
    }
}
